package edu.postech.aadl.launch;

public interface AADLLaunchConfigurationAttributes {
	public static String MAUDE_OPTION = "-no-prelude prelude.maude smt.maude";
	public static String PSPC_PATH = "";
	public static String MAUDE_PATH = "";
	public static String LAUNCH_CONFIGURATION_TYPE_ID = "edu.postech.aadl.launch.launchConfigurationType";
}
